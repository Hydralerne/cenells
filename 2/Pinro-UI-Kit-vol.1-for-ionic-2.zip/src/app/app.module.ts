import { NgModule } from '@angular/core';
import { IonicApp, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';

import { Main } from '../pages/main/main';
import { Login1 } from '../pages/login-1/login-1';
import { Login2 } from '../pages/login-2/login-2';
import { Login3 } from '../pages/login-3/login-3';
import { Login4 } from '../pages/login-4/login-4';
import { Login5 } from '../pages/login-5/login-5';
import { Login6 } from '../pages/login-6/login-6';
import { Login7 } from '../pages/login-7/login-7';
import { Login8 } from '../pages/login-8/login-8';
import { Login9 } from '../pages/login-9/login-9';
import { Login10 } from '../pages/login-10/login-10';
import { Login11 } from '../pages/login-11/login-11';
import { Login12 } from '../pages/login-12/login-12';
import { Login13 } from '../pages/login-13/login-13';

@NgModule({
  declarations: [
    MyApp,
    Main,
    Login1,
    Login2,
    Login3,
    Login4,
    Login5,
    Login6,
    Login7,
    Login8,
    Login9,
    Login10,
    Login11,
    Login12,
    Login13
  ],
  imports: [
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    Main,
    Login1,
    Login2,
    Login3,
    Login4,
    Login5,
    Login6,
    Login7,
    Login8,
    Login9,
    Login10,
    Login11,
    Login12,
    Login13
  ],
  providers: []
})
export class AppModule {}
