import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from 'ionic-native';

import { Main } from '../pages/main/main';
import { Login1 } from '../pages/login-1/login-1';
import { Login2 } from '../pages/login-2/login-2';
import { Login3 } from '../pages/login-3/login-3';
import { Login4 } from '../pages/login-4/login-4';
import { Login5 } from '../pages/login-5/login-5';
import { Login6 } from '../pages/login-6/login-6';
import { Login7 } from '../pages/login-7/login-7';
import { Login8 } from '../pages/login-8/login-8';
import { Login9 } from '../pages/login-9/login-9';
import { Login10 } from '../pages/login-10/login-10';
import { Login11 } from '../pages/login-11/login-11';
import { Login12 } from '../pages/login-12/login-12';
import { Login13 } from '../pages/login-13/login-13';

@Component({
  templateUrl: 'app.html',
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  root = Main;
  rootPage: any = Main;

  pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Screen 1', component: Login1 },
      { title: 'Screen 2', component: Login2 },
      { title: 'Screen 3', component: Login3 },
      { title: 'Screen 4', component: Login4 },
      { title: 'Screen 5', component: Login5 },
      { title: 'Screen 6', component: Login6 },
      { title: 'Screen 7', component: Login7 },
      { title: 'Screen 8', component: Login8 },
      { title: 'Screen 9', component: Login9 },
      { title: 'Screen 10', component: Login10 },
      { title: 'Screen 11', component: Login11 },
      { title: 'Screen 12', component: Login12},
      { title: 'Screen 13', component: Login13 }
    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
    });
  }

  openHome(){
    //open root page
    this.nav.setRoot(Main);
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}



