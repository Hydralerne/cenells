import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

/*
  Generated class for the Login11 page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-login-11',
  templateUrl: 'login-11.html'
})
export class Login11 {

  constructor(public navCtrl: NavController) {}

  ionViewDidLoad() {
    console.log('Hello Login11 Page');
  }

}
