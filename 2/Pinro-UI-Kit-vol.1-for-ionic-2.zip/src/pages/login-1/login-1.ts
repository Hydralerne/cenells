import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

/*
  Generated class for the Login1 page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-login-1',
  templateUrl: 'login-1.html'
})
export class Login1 {

  constructor(public navCtrl: NavController) {}

  ionViewDidLoad() {
    console.log('Hello Login1 Page');
  }

}
