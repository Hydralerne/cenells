import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

/*
  Generated class for the Login12 page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-login-12',
  templateUrl: 'login-12.html'
})
export class Login12 {

  constructor(public navCtrl: NavController) {}

  ionViewDidLoad() {
    console.log('Hello Login12 Page');
  }

}
