import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-main',
  templateUrl: 'main.html'
})
export class Main {

  constructor(public navCtrl: NavController) {
    
  }

}
