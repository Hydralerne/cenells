import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

/*
  Generated class for the Login10 page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-login-10',
  templateUrl: 'login-10.html'
})
export class Login10 {

  gender = 'male';
  constructor(public navCtrl: NavController) {}

  ionViewDidLoad() {
    console.log('Hello Login10 Page');
  }

}
